Tellus 0.1.3 for Windows (64-bit)

Run Tellus.exe. Keep tigrim.exe in the same folder: it is the TigrimOS agent engine of the
chat panel. Windows may warn that the app is from an unknown publisher (it is not signed):
choose "More info" and "Run anyway".

Without a licence key Tellus runs as the free academic edition, for teaching and learning
(up to 1,000 elements, 2 phases after the initial phase, the basic soil models). A licence
key lifts the limits: the first start asks for it, and activation needs the internet once.
Ask for a key at tellusfem@gmail.com.

Headless MCP server: Tellus.exe --mcp
